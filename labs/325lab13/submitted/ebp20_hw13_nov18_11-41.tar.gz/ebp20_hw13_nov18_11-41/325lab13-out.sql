===========
Evan Putnam
===========
=============
Lab Problem 1
=============

DEPT_NAME           SALARY                                                      
--------------- ----------                                                      
Accounting            2450                                                      
Accounting            1300                                                      
Management            5000                                                      
Operations            1100                                                      
Research              3000                                                      
Research              3000                                                      
Research               800                                                      
Research              2975                                                      
Sales                  950                                                      
Sales                 1500                                                      
Sales                 1250                                                      

DEPT_NAME           SALARY                                                      
--------------- ----------                                                      
Sales                 1250                                                      
Sales                 2850                                                      
Sales                 1600                                                      

14 rows selected.

=============
Lab Problem 2
=============

DEPT_NAME           SALARY                                                      
--------------- ----------                                                      
Accounting            2450                                                      
Accounting            1300                                                      
Management            5000                                                      
Operations            1100                                                      
Research              3000                                                      
Research              3000                                                      
Research               800                                                      
Research              2975                                                      
Sales                  950                                                      
Sales                 1500                                                      
Sales                 1250                                                      
Sales                 1250                                                      
Sales                 2850                                                      
Sales                 1600                                                      
=============
Lab Problem 3
=============

Department     SALARY                                                           
---------- ----------                                                           
Accounting       2450                                                           
Accounting       1300                                                           
Management       5000                                                           
Operations       1100                                                           
Research         3000                                                           
Research         3000                                                           
Research          800                                                           
Research         2975                                                           
Sales             950                                                           
Sales            1500                                                           
Sales            1250                                                           
Sales            1250                                                           
Sales            2850                                                           
Sales            1600                                                           
=============
Lab Problem 4
=============

                  Dept                                                          
Department    Salaries                                                          
---------- -----------                                                          
Accounting   $2,450.00                                                          
Accounting   $1,300.00                                                          
Management   $5,000.00                                                          
Operations   $1,100.00                                                          
Research     $3,000.00                                                          
Research     $3,000.00                                                          
Research       $800.00                                                          
Research     $2,975.00                                                          
Sales          $950.00                                                          
Sales        $1,500.00                                                          
Sales        $1,250.00                                                          
Sales        $1,250.00                                                          
Sales        $2,850.00                                                          
Sales        $1,600.00                                                          
=============
Lab Problem 5
=============

                  Dept                                                          
Department    Salaries                                                          
---------- -----------                                                          
Accounting   $2,450.00                                                          
             $1,300.00                                                          
                                                                                
Management   $5,000.00                                                          
                                                                                
Operations   $1,100.00                                                          
                                                                                
Research     $3,000.00                                                          
             $3,000.00                                                          
               $800.00                                                          
             $2,975.00                                                          
                                                                                
Sales          $950.00                                                          
             $1,500.00                                                          
             $1,250.00                                                          
             $1,250.00                                                          
             $2,850.00                                                          
             $1,600.00                                                          
                                                                                
=============
Lab Problem 6
=============

                  Dept                                                          
Department    Salaries                                                          
---------- -----------                                                          
Accounting   $2,450.00                                                          
             $1,300.00                                                          
********** -----------                                                          
avg          $1,875.00                                                          
                                                                                
Management   $5,000.00                                                          
********** -----------                                                          
avg          $5,000.00                                                          
                                                                                
Operations   $1,100.00                                                          
********** -----------                                                          
avg          $1,100.00                                                          
                                                                                
Research     $3,000.00                                                          
             $3,000.00                                                          
               $800.00                                                          
             $2,975.00                                                          
********** -----------                                                          
avg          $2,443.75                                                          
                                                                                
Sales          $950.00                                                          
             $1,500.00                                                          
             $1,250.00                                                          
             $1,250.00                                                          
             $2,850.00                                                          
             $1,600.00                                                          
********** -----------                                                          
avg          $1,566.67                                                          
                                                                                
=============
Lab Problem 7
=============

Fri Nov 18                                                             page    1
                        Department Salaries and Averages

                  Dept                                                          
Department    Salaries                                                          
---------- -----------                                                          
Accounting   $2,450.00                                                          
             $1,300.00                                                          
********** -----------                                                          
avg          $1,875.00                                                          
                                                                                
Management   $5,000.00                                                          
********** -----------                                                          
avg          $5,000.00                                                          
                                                                                
Operations   $1,100.00                                                          
********** -----------                                                          
avg          $1,100.00                                                          
                                                                                
Research     $3,000.00                                                          
             $3,000.00                                                          
               $800.00                                                          
             $2,975.00                                                          
********** -----------                                                          
avg          $2,443.75                                                          
                                                                                
Sales          $950.00                                                          
             $1,500.00                                                          
             $1,250.00                                                          
             $1,250.00                                                          
             $2,850.00                                                          
             $1,600.00                                                          
********** -----------                                                          
avg          $1,566.67                                                          
                                                                                
=============
Lab Problem 8
=============

Fri Nov 18                                                             page    1
                Deptartment Location, Job Title, and Commission

Dept Location  Job        Commission Cost                                       
-------------- ---------- ---------------                                       
Boston         Clerk                                                            
************** ----------                                                       
Empl at Loc             1                                                       
                                                                                
Chicago        Clerk                                                            
               Manager                                                          
               Sales            $1,400.00                                       
               Sales              $500.00                                       
               Sales              $300.00                                       
               Sales                 $.00                                       
************** ----------                                                       
Empl at Loc             6                                                       
                                                                                
Dallas         Analyst                                                          
               Analyst                                                          
               Manager                                                          
               Clerk                                                            
************** ----------                                                       
Empl at Loc             4                                                       
                                                                                
New York       Clerk                                                            
               Manager                                                          
               President                                                        
************** ----------                                                       
Empl at Loc             3                                                       
                                                                                
=============
Lab Problem 9
=============
